import os, re, sqlite3, logging
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import Application, CommandHandler, CallbackQueryHandler, MessageHandler, ContextTypes, filters

TOKEN = os.getenv("BOT_TOKEN", "").strip()
ADMIN_IDS = {int(x) for x in os.getenv("ADMIN_IDS", "").split(",") if x.strip().isdigit()}
DB = os.getenv("DB_PATH", "finbot.db")
logging.basicConfig(level=logging.INFO)

def db():
    con=sqlite3.connect(DB)
    con.execute("""CREATE TABLE IF NOT EXISTS qa(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        level TEXT, section TEXT, question TEXT, answer TEXT)""")
    con.execute("""CREATE TABLE IF NOT EXISTS users(
        user_id INTEGER PRIMARY KEY, username TEXT, first_name TEXT, joined_at TEXT DEFAULT CURRENT_TIMESTAMP)""")
    return con

def norm(s):
    s=s.lower().strip()
    s=re.sub(r"[إأآا]","ا",s); s=re.sub(r"ى","ي",s); s=re.sub(r"ة","ه",s)
    s=re.sub(r"[^\w\s]"," ",s)
    return " ".join(s.split())

def main_menu():
    rows=[
      [InlineKeyboardButton("📚 الثقافة المالية",callback_data="finance"),
       InlineKeyboardButton("🤖 المساعد الذكي",callback_data="assistant")],
      [InlineKeyboardButton("🐍 تعلم Python",callback_data="python"),
       InlineKeyboardButton("🟨 تعلم JavaScript",callback_data="javascript")],
      [InlineKeyboardButton("📊 إحصائياتي",callback_data="stats"),
       InlineKeyboardButton("🎁 دعوة الأصدقاء",callback_data="invite")],
      [InlineKeyboardButton("🔐 الخصوصية",callback_data="privacy"),
       InlineKeyboardButton("📖 طريقة الاستخدام",callback_data="help")],
      [InlineKeyboardButton("👨‍💻 التواصل مع المطور",callback_data="developer")]
    ]
    return InlineKeyboardMarkup(rows)

def levels_menu():
    return InlineKeyboardMarkup([[InlineKeyboardButton(f"📘 المستوى {i}",callback_data=f"level:{i}")] for i in [1,2,3,4,5,6]]+
                                [[InlineKeyboardButton("⬅️ القائمة الرئيسية",callback_data="home")]])

async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    u=update.effective_user
    with db() as con:
        con.execute("INSERT OR REPLACE INTO users(user_id,username,first_name) VALUES(?,?,?)",(u.id,u.username,u.first_name))
    await update.message.reply_text(
        "مرحبًا بك في FinBot V6 🤖\\nمساعدك للتعلم والثقافة المالية والبرمجة.\\n\\nاختر القسم من القائمة:",
        reply_markup=main_menu())

async def callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    q=update.callback_query
    await q.answer()
    data=q.data
    if data=="home":
        await q.edit_message_text("🏠 القائمة الرئيسية – FinBot V6",reply_markup=main_menu())
    elif data=="finance":
        await q.edit_message_text("📚 اختر المستوى المطلوب:",reply_markup=levels_menu())
    elif data.startswith("level:"):
        level=data.split(":")[1]
        with db() as con:
            rows=con.execute("SELECT section, COUNT(*) FROM qa WHERE level=? GROUP BY section",(level,)).fetchall()
        if not rows:
            msg=f"لم تُضف أسئلة المستوى {level} بعد.\\nيمكن للمطور استيرادها من ملف answers.txt."
        else:
            msg=f"📘 المستوى {level}\\n" + "\\n".join(f"• {s}: {n} سؤال" for s,n in rows)
            msg+="\\n\\nأرسل جزءًا من نص السؤال للبحث عن إجابته."
        await q.edit_message_text(msg,reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("⬅️ المستويات",callback_data="finance")],[InlineKeyboardButton("🏠 الرئيسية",callback_data="home")]]))
        context.user_data["level"]=level
    elif data=="stats":
        with db() as con:
            n=con.execute("SELECT COUNT(*) FROM users").fetchone()[0]
        await q.edit_message_text(f"📊 إحصائياتك\\nمعرّفك: {q.from_user.id}\\nعدد مستخدمي البوت: {n}",reply_markup=main_menu())
    elif data=="invite":
        me=await context.bot.get_me()
        await q.edit_message_text(f"🎁 رابط دعوة البوت:\\nhttps://t.me/{me.username}?start={q.from_user.id}",reply_markup=main_menu())
    elif data=="privacy":
        await q.edit_message_text("🔐 الخصوصية: لا تطلب من الطلاب إرسال كلمات مرور منصة Qureo أو بيانات الدخول الحساسة. هذا الإصدار لا يسجل الدخول إلى المنصة.",reply_markup=main_menu())
    elif data=="help":
        await q.edit_message_text("📖 طريقة الاستخدام:\\n1) اختر الثقافة المالية والمستوى.\\n2) أرسل جزءًا واضحًا من السؤال.\\n3) سيبحث البوت في بنك الأسئلة ويعرض الإجابة المسجلة.\\n\\nإذا لم يجد السؤال، تأكد من صياغته أو اطلب من المطور إضافته.",reply_markup=main_menu())
    elif data=="assistant":
        await q.edit_message_text("🤖 المساعد الذكي: أرسل سؤالك في المحادثة. في هذا الإصدار أستطيع البحث في بنك الإجابات الذي يضيفه المطور.",reply_markup=main_menu())
    elif data in ("python","javascript"):
        lang="Python" if data=="python" else "JavaScript"
        await q.edit_message_text(f"📘 قسم تعلم {lang}\\nسيتم إضافة الدروس والتمارين لهذا القسم لاحقًا.",reply_markup=main_menu())
    elif data=="developer":
        await q.edit_message_text("👨‍💻 للتواصل مع المطور: أضف وسيلة التواصل في إعدادات المشروع.",reply_markup=main_menu())

async def text_message(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query=norm(update.message.text)
    level=context.user_data.get("level")
    with db() as con:
        rows=con.execute("SELECT level,section,question,answer FROM qa").fetchall()
    # exact/contained match first, then token overlap
    best=None; score=0
    for lev,sec,question,answer in rows:
        nq=norm(question)
        if not nq: continue
        if nq in query or query in nq:
            sc=100 + min(len(nq),len(query))/100
        else:
            a=set(query.split()); b=set(nq.split())
            sc=len(a&b)/max(1,len(a|b))*100
        if level and lev==level: sc+=8
        if sc>score: score=sc; best=(lev,sec,question,answer)
    if best and score>=18:
        lev,sec,question,answer=best
        await update.message.reply_text(f"📘 المستوى {lev} – {sec}\\n\\n❓ {question}\\n\\n✅ الإجابة المسجلة:\\n{answer}\\n\\nملاحظة: الإجابة معروضة كما أُدخلت في بنك المحتوى.")
    else:
        await update.message.reply_text("لم أجد سؤالًا مطابقًا في بنك الإجابات حتى الآن. أرسل نص السؤال كاملًا أو تواصل مع المطور لإضافة السؤال.")

async def admin_import(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if update.effective_user.id not in ADMIN_IDS:
        return await update.message.reply_text("هذا الأمر للمطور فقط.")
    await update.message.reply_text("أرسل ملف CSV بالأعمدة: level,section,question,answer. استخدم UTF-8. سيتم استيراده في الخطوة التالية.")

def main():
    if not TOKEN:
        raise SystemExit("ضع BOT_TOKEN في متغيرات البيئة أولًا.")
    app=Application.builder().token(TOKEN).build()
    app.add_handler(CommandHandler("start",start))
    app.add_handler(CommandHandler("admin_import",admin_import))
    app.add_handler(CallbackQueryHandler(callback))
    app.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND,text_message))
    app.run_polling()

if __name__=="__main__":
    main()
